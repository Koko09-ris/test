export { default as Navbar } from './Navbar';
export { default as Header } from './Header';
export { default as Project } from './Project';
export { default as Resume } from './Resume';
export { default as About } from './About';
export { default as Contact } from './Contact';