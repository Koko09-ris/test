# Getting Started with Express JS

This project was bootstrapped with [Express JS](http://expressjs.com/).

## Available Scripts

In the project directory, you can run:

### `npm dev`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.\
You will also see any lint errors in the console.

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:PORT](http://localhost:PORT) to view it in the browser.

